<?php

namespace App\Http\Resources\Asistencia;

use Illuminate\Http\Resources\Json\ResourceCollection;

class AsistenciaCollection extends ResourceCollection
{
    public function toArray($request)
    {

    }
}
