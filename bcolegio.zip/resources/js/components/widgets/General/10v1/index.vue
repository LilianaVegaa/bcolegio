<template>
  <div class="d-flex flex-wrap flex-column align-items-center">
    <div class="air__utils__avatar air__utils__avatar--size64 mb-3">
      <img src="resources/images/avatars/5.jpg" alt="Mary Stanform"/>
    </div>
    <div class="text-center">
      <div class="text-dark font-weight-bold font-size-18">Mary Stanform</div>
      <div class="text-uppercase font-size-12 mb-3">Support team</div>
      <button type="button" class="btn btn-primary btn-with-addon">
        <span class="btn-addon">
          <i class="btn-addon-icon fe fe-plus-circle"/>
        </span>
        Request Access
      </button>
    </div>
  </div>
</template>
<script>
export default {
  name: 'AirGeneral',
}
</script>
